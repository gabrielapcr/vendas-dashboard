package com.seuprojeto.vendasapi.controller;

import com.seuprojeto.vendasapi.model.Venda;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/vendas")
public class VendaController {

    private List<Venda> vendas = List.of(
        new Venda(1L, "Produto A", 10, LocalDate.of(2025, 4, 1), 200.0),
        new Venda(2L, "Produto B", 5, LocalDate.of(2025, 4, 2), 150.0),
        new Venda(3L, "Produto C", 15, LocalDate.of(2025, 4, 3), 300.0),
        new Venda(4L, "Produto A", 8, LocalDate.of(2025, 4, 4), 160.0)
    );

    @GetMapping
    public List<Venda> getVendas(
        @RequestParam(required = false) String produto,
        @RequestParam(required = false) String dataInicial,
        @RequestParam(required = false) String dataFinal
    ) {
        return vendas.stream()
            .filter(v -> produto == null || v.getProduto().equalsIgnoreCase(produto))
            .filter(v -> dataInicial == null || !v.getData().isBefore(LocalDate.parse(dataInicial)))
            .filter(v -> dataFinal == null || !v.getData().isAfter(LocalDate.parse(dataFinal)))
            .collect(Collectors.toList());
    }
}

