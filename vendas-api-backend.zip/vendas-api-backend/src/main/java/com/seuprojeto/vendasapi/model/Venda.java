package com.seuprojeto.vendasapi.model;

import java.time.LocalDate;

public class Venda {
    private Long id;
    private String produto;
    private int quantidade;
    private LocalDate data;
    private double valorTotal;

    public Venda(Long id, String produto, int quantidade, LocalDate data, double valorTotal) {
        this.id = id;
        this.produto = produto;
        this.quantidade = quantidade;
        this.data = data;
        this.valorTotal = valorTotal;
    }

    public Long getId() { return id; }
    public String getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }
    public LocalDate getData() { return data; }
    public double getValorTotal() { return valorTotal; }
}
