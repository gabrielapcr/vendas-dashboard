package com.seuprojeto.vendasapi.controller;

import com.seuprojeto.vendasapi.model.UserLoginRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UserLoginRequest login) {
    System.out.println("Usuário: " + login.getUsername());
    System.out.println("Senha: " + login.getPassword());

    if ("admin".equals(login.getUsername()) && "senha123".equals(login.getPassword())) {
        Map<String, String> token = new HashMap<>();
        token.put("token", "fake-token");
        return ResponseEntity.ok(token);
    }
    return ResponseEntity.status(401).body("Credenciais inválidas");
}
}

