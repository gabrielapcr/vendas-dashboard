import React, { useEffect, useState } from "react";
import Dashboard from "./pages/dashboards";

function App() {
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true); 

  useEffect(() => {
    const tokenSalvo = localStorage.getItem("token");

    if (!tokenSalvo) {
      fetch("http://localhost:8080/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: "admin", password: "senha123" }),
      })
        .then((res) => {
          if (!res.ok) {
            throw new Error("Credenciais inválidas");
          }
          return res.json();
        })
        .then((data) => {
          localStorage.setItem("token", data.token);
          setToken(data.token);
        })
        .catch((err) => {
          console.error("Erro no login automático:", err);
        })
        .finally(() => {
          setLoading(false); 
        });
    } else {
      setToken(tokenSalvo);
      setLoading(false);
    }
  }, []);

  if (loading) return <div>Carregando...</div>; 

  return token ? <Dashboard /> : <div>Erro de autenticação</div>;
}

export default App;
