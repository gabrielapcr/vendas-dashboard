import React, { useEffect, useState } from "react";
import Filtros from "./filtros";
import Graficos from "./Graficos";

export default function Dashboard() {
  const [vendas, setVendas] = useState([]);
  const [produto, setProduto] = useState("");
  const [dataInicio, setDataInicio] = useState(null);
  const [dataFim, setDataFim] = useState(null);

  const fetchVendas = async () => {
    let url = "http://localhost:8080/vendas";
    const params = [];

    if (produto) params.push(`produto=${produto}`);
    if (dataInicio) params.push(`dataInicial=${dataInicio.toISOString().split("T")[0]}`);
    if (dataFim) params.push(`dataFinal=${dataFim.toISOString().split("T")[0]}`);
    if (params.length > 0) url += `?${params.join("&")}`;

    const token = localStorage.getItem("token");
    if (!token) {
      console.warn("Token não encontrado.");
      return;
    }

    try {
      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        console.error("Erro ao buscar vendas:", response.status);
        return;
      }

      const data = await response.json();
      setVendas(data);
    } catch (error) {
      console.error("Erro de rede:", error.message);
    }
  };

  useEffect(() => {
    fetchVendas();
  }, [produto, dataInicio, dataFim]);

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Dashboard de Vendas</h2>
      <Filtros
        produto={produto}
        setProduto={setProduto}
        dataInicio={dataInicio}
        setDataInicio={setDataInicio}
        dataFim={dataFim}
        setDataFim={setDataFim}
      />
      <Graficos vendas={vendas} />
    </div>
  );
}
