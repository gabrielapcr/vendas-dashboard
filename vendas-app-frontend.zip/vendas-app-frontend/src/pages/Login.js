import React, { useState } from "react";
import axios from "axios";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      const res = await axios.post("http://localhost:8080/auth/login", {
        username,
        password,
      });
      localStorage.setItem("token", res.data.token);
      window.location.reload();
    } catch {
      alert("Credenciais inválidas");
    }
  };

  return (
    <div style={{ padding: "2rem", backgroundColor: "#e3f2fd" }}>
      <h2 style={{ color: "#ff6f00" }}>Login</h2>
      <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Usuário" /><br />
      <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Senha" type="password" /><br />
      <button onClick={handleLogin} style={{ backgroundColor: "#ff6f00", color: "white" }}>Entrar</button>
    </div>
  );
}

export default Login;
