import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

export default function Filtros({ produto, setProduto, dataInicio, setDataInicio, dataFim, setDataFim }) {
  return (
    <div style={{ marginBottom: "1rem" }}>
      <input
        placeholder="Produto"
        value={produto}
        onChange={(e) => setProduto(e.target.value)}
      />
      <DatePicker
        selected={dataInicio}
        onChange={(date) => setDataInicio(date)}
        placeholderText="Data Início"
      />
      <DatePicker
        selected={dataFim}
        onChange={(date) => setDataFim(date)}
        placeholderText="Data Fim"
      />
    </div>
  );
}
