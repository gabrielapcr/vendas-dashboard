import React from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar, ResponsiveContainer
} from "recharts";

export default function Graficos({ vendas }) {
  if (!vendas || vendas.length === 0) {
    return <p>Nenhuma venda encontrada.</p>;
  }

  const produtosUnicos = [...new Set(vendas.map(v => v.produto))];

  const porProduto = produtosUnicos.map(prod => {
    const totalQuantidade = vendas
      .filter(v => v.produto === prod)
      .reduce((sum, v) => sum + v.quantidade, 0);

    const totalValor = vendas
      .filter(v => v.produto === prod)
      .reduce((sum, v) => sum + v.valorTotal, 0);

    return { produto: prod, quantidade: totalQuantidade, valorTotal: totalValor };
  });

  return (
    <>
      <h3>Quantidade de Vendas por Produto</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={porProduto}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="produto" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="quantidade" fill="#ff6600" />
          <Bar dataKey="valorTotal" fill="#007bff" />
        </BarChart>
      </ResponsiveContainer>

      <h3 style={{ marginTop: "2rem" }}>Evolução das Vendas ao Longo do Tempo</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={vendas}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="data"
            tickFormatter={(d) => new Date(d).toLocaleDateString()}
          />
          <YAxis />
          <Tooltip
            labelFormatter={(d) => new Date(d).toLocaleDateString()}
          />
          <Legend />
          <Line type="monotone" dataKey="quantidade" stroke="#ff6600" />
        </LineChart>
      </ResponsiveContainer>
    </>
  );
}
